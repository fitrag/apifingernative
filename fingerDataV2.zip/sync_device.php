<?php
/**
 * API Sinkronisasi User ke Mesin Fingerprint ZKTeco
 */

require_once 'config.php';
require_once 'settings.php';
require_once 'sync_functions.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? $_POST['action'] ?? '';
$conn = getConnection();

switch ($action) {
    case 'devices':
        $devices = getActiveDevices($conn);
        echo json_encode(['success' => true, 'devices' => $devices]);
        break;

    case 'test_connection':
        $ip = $_POST['ip'] ?? $_GET['ip'] ?? '';
        $port = intval($_POST['port'] ?? $_GET['port'] ?? 4370);

        if (empty($ip)) {
            echo json_encode(['success' => false, 'message' => 'IP Address diperlukan']);
            break;
        }

        $result = testDeviceConnection($ip, $port);
        echo json_encode($result);
        break;

    case 'get_device_users':
        $ip = $_POST['ip'] ?? $_GET['ip'] ?? '';
        $port = intval($_POST['port'] ?? $_GET['port'] ?? 4370);

        if (empty($ip)) {
            echo json_encode(['success' => false, 'message' => 'IP Address diperlukan']);
            break;
        }

        $result = getUsersFromDevice($ip, $port);
        echo json_encode($result);
        break;

    case 'sync_user':
        $userid = $_POST['userid'] ?? $_GET['userid'] ?? 0;
        $deviceIP = $_POST['device_ip'] ?? $_GET['device_ip'] ?? null;

        if (!$userid) {
            echo json_encode(['success' => false, 'message' => 'User ID diperlukan']);
            break;
        }

        $result = syncUserToDevice($conn, (int) $userid, $deviceIP);
        echo json_encode($result);
        break;

    case 'sync_users':
        $input = json_decode(file_get_contents('php://input'), true);
        $userids = $input['userids'] ?? [];
        $deviceIP = $input['device_ip'] ?? null;

        if (empty($userids)) {
            echo json_encode(['success' => false, 'message' => 'User IDs diperlukan']);
            break;
        }

        $result = syncUsersToDevice($conn, array_map('intval', $userids), $deviceIP);
        echo json_encode($result);
        break;

    case 'sync_all':
        $deviceIP = $_POST['device_ip'] ?? $_GET['device_ip'] ?? null;
        $result = syncAllUsersToDevice($conn, $deviceIP);
        echo json_encode($result);
        break;

    case 'delete_user':
        $badgenumber = $_POST['badgenumber'] ?? $_GET['badgenumber'] ?? '';
        $deviceIP = $_POST['device_ip'] ?? $_GET['device_ip'] ?? null;

        if (!$badgenumber) {
            echo json_encode(['success' => false, 'message' => 'Badge number diperlukan']);
            break;
        }

        $result = deleteUserFromDevice($conn, $badgenumber, $deviceIP);
        echo json_encode($result);
        break;

    case 'pending':
        $pending = getPendingCommands($conn);
        echo json_encode(['success' => true, 'pending' => $pending, 'count' => count($pending)]);
        break;

    case 'clear_pending':
        $deleted = clearOldPendingCommands($conn);
        echo json_encode(['success' => true, 'message' => "{$deleted} perintah lama dihapus"]);
        break;

    default:
        echo json_encode([
            'success' => false,
            'message' => 'Action tidak valid',
            'available_actions' => ['devices', 'test_connection', 'get_device_users', 'sync_user', 'sync_users', 'sync_all', 'delete_user', 'pending', 'clear_pending']
        ]);
}

$conn->close();
