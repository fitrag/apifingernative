<?php
/**
 * Fungsi-fungsi Sinkronisasi User ke Mesin Fingerprint ZKTeco
 * Menggunakan 2 metode:
 * 1. Koneksi langsung via UDP port 4370 (ZKLib)
 * 2. Fallback ke ADMS protocol via tabel devcmds
 */

require_once 'ZKLib.php';

/**
 * Ambil daftar mesin fingerprint yang aktif dari database
 */
function getActiveDevices($conn)
{
    $result = $conn->query("SELECT SN, Alias, DeviceName, IPAddress FROM iclock WHERE State = 1 AND DelTag = 0");
    $devices = [];
    while ($row = $result->fetch_assoc()) {
        $devices[] = $row;
    }
    return $devices;
}

/**
 * Kirim perintah ke mesin via tabel devcmds (ADMS protocol)
 */
function sendDeviceCommand($conn, $sn, $cmdContent, $userId = 0)
{
    $stmt = $conn->prepare("INSERT INTO devcmds (SN_id, CmdContent, CmdCommitTime, CmdReturn, User_id) VALUES (?, ?, NOW(), 0, ?)");
    $stmt->bind_param("ssi", $sn, $cmdContent, $userId);
    $result = $stmt->execute();
    $stmt->close();
    return $result;
}

/**
 * Generate perintah DATA USER untuk ADMS protocol
 */
function generateUserCommand($user)
{
    $pin = ltrim($user['badgenumber'], '0') ?: '1';
    $name = $user['name'];
    $card = $user['Card'] ?? '';
    $passwd = $user['Password'] ?? '';
    $pri = $user['Privilege'] ?? 0;

    return "DATA USER PIN={$pin}\tName={$name}\tPri={$pri}\tPasswd={$passwd}\tCard={$card}\tGrp=1\tTZ=0000000100000000";
}

/**
 * Sinkronisasi satu user ke mesin fingerprint
 * Mencoba koneksi langsung dulu, fallback ke ADMS jika gagal
 */
function syncUserToDevice($conn, $userid, $deviceIP = null)
{
    // Ambil data user
    $stmt = $conn->prepare("SELECT * FROM userinfo WHERE userid = ?");
    $stmt->bind_param("i", $userid);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$user) {
        return ['success' => false, 'message' => 'User tidak ditemukan'];
    }

    // Ambil daftar mesin
    $devices = getActiveDevices($conn);
    if (empty($devices)) {
        return ['success' => false, 'message' => 'Tidak ada mesin fingerprint yang aktif'];
    }

    $synced = 0;
    $failed = 0;
    $errors = [];
    $method = 'adms'; // Default method

    foreach ($devices as $device) {
        $ip = $device['IPAddress'];
        $sn = $device['SN'];

        // Filter by IP jika specified
        if ($deviceIP && $ip !== $deviceIP) continue;

        $success = false;

        // Coba koneksi langsung via ZKLib
        if (!empty($ip)) {
            $zk = new ZKLib($ip, 4370);
            if ($zk->connect()) {
                $zk->disableDevice();

                $pin = ltrim($user['badgenumber'], '0') ?: '1';
                $result = $zk->setUser(
                    $pin,
                    $user['name'],
                    $user['Password'] ?? '',
                    $user['Privilege'] ?? 0,
                    ''
                );

                if (!$result) {
                    // Coba format binary
                    $result = $zk->setUserBinary(
                        $pin,
                        $user['name'],
                        $user['Password'] ?? '',
                        $user['Privilege'] ?? 0,
                        ''
                    );
                }

                $zk->enableDevice();
                $zk->disconnect();

                if ($result) {
                    $success = true;
                    $method = 'direct';
                }
            }
        }

        // Fallback ke ADMS protocol jika koneksi langsung gagal
        if (!$success && !empty($sn)) {
            $cmd = generateUserCommand($user);
            if (sendDeviceCommand($conn, $sn, $cmd, $userid)) {
                $success = true;
                $method = 'adms';
            }
        }

        if ($success) {
            $synced++;
        } else {
            $failed++;
            $errors[] = "Gagal sync ke " . ($ip ?: $sn);
        }
    }

    $methodText = $method === 'direct' ? ' (koneksi langsung)' : ' (via ADMS - menunggu polling mesin)';

    return [
        'success' => $synced > 0,
        'message' => "Sinkronisasi ke {$synced} mesin berhasil{$methodText}" . ($failed > 0 ? ", {$failed} gagal" : ""),
        'synced' => $synced,
        'failed' => $failed,
        'method' => $method,
        'errors' => $errors
    ];
}

/**
 * Sinkronisasi banyak user sekaligus
 */
function syncUsersToDevice($conn, $userids, $deviceIP = null)
{
    if (empty($userids)) {
        return ['success' => false, 'message' => 'Tidak ada user untuk disinkronisasi'];
    }

    $devices = getActiveDevices($conn);
    if (empty($devices)) {
        return ['success' => false, 'message' => 'Tidak ada mesin fingerprint yang aktif'];
    }

    // Ambil data semua user
    $placeholders = implode(',', array_fill(0, count($userids), '?'));
    $types = str_repeat('i', count($userids));
    $stmt = $conn->prepare("SELECT * FROM userinfo WHERE userid IN ($placeholders)");
    $stmt->bind_param($types, ...$userids);
    $stmt->execute();
    $result = $stmt->get_result();

    $users = [];
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
    $stmt->close();

    $synced = 0;
    $failed = 0;
    $errors = [];

    foreach ($devices as $device) {
        $ip = $device['IPAddress'];
        $sn = $device['SN'];

        if ($deviceIP && $ip !== $deviceIP) continue;

        // Gunakan ADMS protocol untuk bulk sync (lebih reliable)
        foreach ($users as $user) {
            $cmd = generateUserCommand($user);
            if (sendDeviceCommand($conn, $sn, $cmd, $user['userid'])) {
                $synced++;
            } else {
                $failed++;
            }
        }
    }

    $totalCommands = count($users) * count($devices);

    return [
        'success' => $synced > 0,
        'message' => "Sinkronisasi {$synced}/{$totalCommands} user berhasil (via ADMS - menunggu polling mesin)",
        'synced' => $synced,
        'failed' => $failed,
        'users' => count($users),
        'devices' => count($devices),
        'method' => 'adms',
        'errors' => $errors
    ];
}

/**
 * Sinkronisasi semua user ke mesin
 */
function syncAllUsersToDevice($conn, $deviceIP = null)
{
    $result = $conn->query("SELECT userid FROM userinfo WHERE DelTag IS NULL OR DelTag = 0");
    $userids = [];
    while ($row = $result->fetch_assoc()) {
        $userids[] = $row['userid'];
    }

    if (empty($userids)) {
        return ['success' => false, 'message' => 'Tidak ada user untuk disinkronisasi'];
    }

    return syncUsersToDevice($conn, $userids, $deviceIP);
}

/**
 * Hapus user dari mesin fingerprint
 */
function deleteUserFromDevice($conn, $badgenumber, $deviceIP = null)
{
    $devices = getActiveDevices($conn);
    if (empty($devices)) {
        return ['success' => false, 'message' => 'Tidak ada mesin fingerprint yang aktif'];
    }

    $pin = ltrim($badgenumber, '0') ?: '1';
    $synced = 0;
    $failed = 0;
    $errors = [];

    foreach ($devices as $device) {
        $ip = $device['IPAddress'];
        $sn = $device['SN'];

        if ($deviceIP && $ip !== $deviceIP) continue;

        $success = false;

        // Coba koneksi langsung
        if (!empty($ip)) {
            $zk = new ZKLib($ip, 4370);
            if ($zk->connect()) {
                $zk->disableDevice();
                $result = $zk->deleteUser($pin);
                $zk->enableDevice();
                $zk->disconnect();

                if ($result) {
                    $success = true;
                }
            }
        }

        // Fallback ke ADMS
        if (!$success && !empty($sn)) {
            $cmd = "DATA DEL_USER PIN={$pin}";
            if (sendDeviceCommand($conn, $sn, $cmd, 0)) {
                $success = true;
            }
        }

        if ($success) {
            $synced++;
        } else {
            $failed++;
            $errors[] = "Gagal hapus dari " . ($ip ?: $sn);
        }
    }

    return [
        'success' => $synced > 0,
        'message' => "Hapus dari {$synced} mesin berhasil" . ($failed > 0 ? ", {$failed} gagal" : ""),
        'synced' => $synced,
        'failed' => $failed,
        'errors' => $errors
    ];
}

/**
 * Test koneksi ke mesin
 */
function testDeviceConnection($ip, $port = 4370)
{
    $zk = new ZKLib($ip, $port);
    $result = $zk->testConnection();

    if ($result['success']) {
        // Coba ambil jumlah user
        $zk2 = new ZKLib($ip, $port);
        if ($zk2->connect()) {
            $users = $zk2->getUsers();
            $result['user_count'] = count($users);
            $zk2->disconnect();
        }
    }

    return $result;
}

/**
 * Ambil daftar user dari mesin
 */
function getUsersFromDevice($ip, $port = 4370)
{
    $zk = new ZKLib($ip, $port);
    if ($zk->connect()) {
        $users = $zk->getUsers();
        $zk->disconnect();
        return ['success' => true, 'users' => $users, 'count' => count($users)];
    }
    return ['success' => false, 'message' => 'Tidak dapat terhubung ke mesin: ' . $zk->lastError];
}

/**
 * Cek pending commands di tabel devcmds
 */
function getPendingCommands($conn, $limit = 50)
{
    $result = $conn->query("SELECT d.*, u.name FROM devcmds d LEFT JOIN userinfo u ON d.User_id = u.userid WHERE d.CmdReturn = 0 ORDER BY d.CmdCommitTime DESC LIMIT $limit");
    $pending = [];
    while ($row = $result->fetch_assoc()) {
        $pending[] = $row;
    }
    return $pending;
}

/**
 * Hapus pending commands yang sudah lama
 */
function clearOldPendingCommands($conn, $hours = 1)
{
    $conn->query("DELETE FROM devcmds WHERE CmdReturn = 0 AND CmdCommitTime < DATE_SUB(NOW(), INTERVAL $hours HOUR)");
    return $conn->affected_rows;
}
