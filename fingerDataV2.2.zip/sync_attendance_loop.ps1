# Sync Attendance Loop - Membaca interval dari settings.json
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir

$lastSyncTime = [DateTime]::MinValue

while ($true) {
    $now = Get-Date
    
    # Baca interval dari settings.json
    $syncIntervalMinutes = 60
    $settingsFile = Join-Path $scriptDir "settings.json"
    if (Test-Path $settingsFile) {
        try {
            $settings = Get-Content $settingsFile -Raw | ConvertFrom-Json
            if ($settings.sync_interval) {
                $syncIntervalMinutes = [int]$settings.sync_interval
            }
        } catch {
            # Ignore errors, use default
        }
    }
    
    # Run sync attendance ke API (sesuai interval dari settings)
    if (($now - $lastSyncTime).TotalMinutes -ge $syncIntervalMinutes) {
        try {
            php cron_sync_attendance.php 2>&1 | Out-Null
            $lastSyncTime = $now
        } catch {
            # Ignore errors
        }
    }
    
    # Check setiap 30 detik
    Start-Sleep -Seconds 30
}
