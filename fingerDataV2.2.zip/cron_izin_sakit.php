<?php
/**
 * Cron Job: Notifikasi WhatsApp untuk Siswa Izin/Sakit
 * Mengambil data dari API SIAKAD dan mengirim notifikasi langsung
 */

require_once 'config.php';
require_once 'wa_queue.php';
require_once 'settings.php';

// Ambil konfigurasi dari settings
$WA_API_URL = getSetting('wa_api_url', 'http://127.0.0.1:8000/api/send-message');
$WA_TOKEN = getSetting('wa_api_token', '');
$SIAKAD_API_URL = getSetting('siakad_api_url', 'https://siakads.kurikulum-skansa.id/api/attendance/absences');
$SIAKAD_API_TOKEN = getSetting('siakad_api_token', '');

// File untuk tracking notifikasi yang sudah dikirim
define('SENT_IZIN_LOG_FILE', __DIR__ . '/sent_izin_log.json');

function getSentIzinLog() {
    if (file_exists(SENT_IZIN_LOG_FILE)) {
        $content = file_get_contents(SENT_IZIN_LOG_FILE);
        $data = json_decode($content, true);
        if (is_array($data)) return $data;
    }
    return [];
}

function saveSentIzinLog($data) {
    file_put_contents(SENT_IZIN_LOG_FILE, json_encode($data), LOCK_EX);
}

function isAlreadyNotifiedIzin($id) {
    $log = getSentIzinLog();
    return isset($log[strval($id)]);
}

function markAsNotifiedIzin($id) {
    $log = getSentIzinLog();
    
    // Hapus data lebih dari 7 hari (cukup karena ID dari API unik per hari)
    $cutoff = time() - (7 * 24 * 60 * 60);
    foreach ($log as $k => $v) {
        if (is_numeric($v) && $v < $cutoff) {
            unset($log[$k]);
        }
    }
    
    $log[strval($id)] = time();
    saveSentIzinLog($log);
}

function fetchAbsencesFromAPI() {
    global $SIAKAD_API_URL, $SIAKAD_API_TOKEN;
    
    $ch = curl_init();
    
    $headers = ['Content-Type: application/json', 'Accept: application/json'];
    if (!empty($SIAKAD_API_TOKEN)) {
        $headers[] = 'Authorization: Bearer ' . $SIAKAD_API_TOKEN;
    }
    
    curl_setopt_array($ch, [
        CURLOPT_URL => $SIAKAD_API_URL,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        logMessage("CURL Error: $error");
        return null;
    }
    
    if ($httpCode !== 200) {
        logMessage("API Error: HTTP $httpCode - $response");
        return null;
    }
    
    $data = json_decode($response, true);
    return $data;
}

function formatPhone($phone) {
    // Hapus karakter non-digit
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    // Jika dimulai dengan 0, ganti dengan 62
    if (substr($phone, 0, 1) === '0') {
        $phone = '62' . substr($phone, 1);
    }
    
    return $phone;
}

function sendWhatsApp($phone, $message) {
    global $WA_API_URL, $WA_TOKEN;
    
    $ch = curl_init();
    
    $data = [
        'phone' => $phone,
        'message' => $message
    ];
    
    curl_setopt_array($ch, [
        CURLOPT_URL => $WA_API_URL,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $WA_TOKEN
        ],
        CURLOPT_TIMEOUT => 30
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        logMessage("WA CURL Error: $error");
        return false;
    }
    
    return $httpCode >= 200 && $httpCode < 300;
}

function logMessage($msg) {
    $timestamp = date('Y-m-d H:i:s');
    $logFile = __DIR__ . '/cron_izin_log.txt';
    file_put_contents($logFile, "[$timestamp] $msg\n", FILE_APPEND);
}

// Main Process
logMessage("=== Mulai Cron Izin/Sakit ===");

// Fetch data dari API SIAKAD
$apiData = fetchAbsencesFromAPI();

if ($apiData === null) {
    logMessage("Gagal mengambil data dari API");
    exit;
}

if (!isset($apiData['success']) || !$apiData['success']) {
    logMessage("API response tidak sukses");
    exit;
}

$absences = $apiData['data'] ?? [];
$summary = $apiData['summary'] ?? [];

if (empty($absences)) {
    logMessage("Tidak ada data izin/sakit");
    exit;
}

$tanggal = $summary['date'] ?? date('Y-m-d');
$formattedDate = date('d/m/Y', strtotime($tanggal));

logMessage("Tanggal: $tanggal | Sakit: " . ($summary['sakit'] ?? 0) . " | Izin: " . ($summary['izin'] ?? 0) . " | Total: " . ($summary['total'] ?? count($absences)));

$sent = 0;
$skipped = 0;
$failed = 0;

foreach ($absences as $absence) {
    $id = strval($absence['id']); // Pastikan string untuk konsistensi
    $nama = $absence['nama'];
    $phone = $absence['no_tlp'];
    $keterangan = $absence['keterangan']; // "Sakit" atau "Izin"
    
    // Cek apakah sudah pernah dikirim notifikasi (PENTING: cek dulu sebelum proses apapun)
    if (isAlreadyNotifiedIzin($id)) {
        $skipped++;
        continue;
    }
    
    // LANGSUNG tandai sebagai sudah diproses untuk mencegah duplikasi
    // jika cron dijalankan bersamaan
    markAsNotifiedIzin($id);
    
    if (empty($phone)) {
        logMessage("Skip: Nomor WA kosong untuk $nama (ID: $id)");
        $skipped++;
        continue;
    }
    
    // Format nomor telepon
    $phone = formatPhone($phone);
    
    // Tentukan emoji dan label
    $issakit = strtolower($keterangan) === 'sakit';
    $emoji = $issakit ? '🏥' : '📝';
    $typeLabel = strtoupper($keterangan);
    
    // Format pesan
    $message = "{$emoji} *NOTIFIKASI {$typeLabel}*\n\n";
    $message .= "Nama: {$nama}\n";
    $message .= "Status: {$keterangan}\n";
    $message .= "Tanggal: {$formattedDate}\n\n";
    
    if ($issakit) {
        $message .= "_Semoga lekas sembuh dan dapat kembali beraktivitas._";
    } else {
        $message .= "_Terima kasih telah menginformasikan._";
    }
    
    // Kirim WhatsApp
    $result = sendWhatsApp($phone, $message);
    
    if ($result) {
        logMessage("SUCCESS: {$keterangan} - {$nama} -> {$phone}");
        $sent++;
    } else {
        logMessage("FAILED: {$keterangan} - {$nama} -> {$phone}");
        addToWaQueue($phone, $message, 'izin_' . strtolower($keterangan), $id, $tanggal);
        $failed++;
    }
    
    // Delay 500ms antar pengiriman untuk menghindari rate limit
    usleep(500000);
}

logMessage("=== Selesai: $sent terkirim, $skipped dilewati, $failed gagal ===");
