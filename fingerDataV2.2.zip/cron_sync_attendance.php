<?php
/**
 * Cron Job: Sync Attendance Data ke API
 * Mengirim data absensi dari tabel checkinout ke API eksternal
 * 
 * Jalankan dengan: php cron_sync_attendance.php
 * Atau schedule di Task Scheduler/crontab
 */

require_once 'config.php';
require_once 'settings.php';

// Ambil konfigurasi dari settings
$SYNC_API_URL = getSetting('sync_api_url', 'http://127.0.0.1:8000/api/attendance/sync');
$SYNC_API_TOKEN = getSetting('sync_api_token', '');

define('LAST_SYNC_ID_FILE', __DIR__ . '/last_sync_attendance_id.txt');
define('SYNC_LOG_FILE', __DIR__ . '/cron_sync_attendance_log.txt');

/**
 * Log message ke file
 */
function syncLog($msg) {
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents(SYNC_LOG_FILE, "[$timestamp] $msg\n", FILE_APPEND);
}

/**
 * Ambil ID terakhir yang sudah di-sync
 */
function getLastSyncId() {
    if (file_exists(LAST_SYNC_ID_FILE)) {
        return (int) trim(file_get_contents(LAST_SYNC_ID_FILE));
    }
    return 0;
}

/**
 * Simpan ID terakhir yang sudah di-sync
 */
function saveLastSyncId($id) {
    file_put_contents(LAST_SYNC_ID_FILE, $id, LOCK_EX);
}

/**
 * Kirim data ke API
 */
function sendToApi($data) {
    global $SYNC_API_URL, $SYNC_API_TOKEN;
    
    $ch = curl_init();
    
    $headers = [
        'Content-Type: application/json',
        'Accept: application/json'
    ];
    
    // Tambahkan token jika ada
    if (!empty($SYNC_API_TOKEN)) {
        $headers[] = 'Authorization: Bearer ' . $SYNC_API_TOKEN;
    }
    
    curl_setopt_array($ch, [
        CURLOPT_URL => $SYNC_API_URL,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CONNECTTIMEOUT => 10
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        syncLog("CURL Error: $error");
        return ['success' => false, 'error' => $error];
    }
    
    syncLog("API Response [$httpCode]: $response");
    
    return [
        'success' => $httpCode >= 200 && $httpCode < 300,
        'http_code' => $httpCode,
        'response' => json_decode($response, true)
    ];
}

// Main Process
syncLog("=== Starting Attendance Sync ===");
syncLog("API URL: $SYNC_API_URL");

$conn = getConnection();
$lastId = getLastSyncId();

syncLog("Last synced ID: $lastId");

// Query data absensi baru dengan NIS dari kolom title di userinfo
$sql = "SELECT 
            c.id,
            c.userid,
            c.checktime,
            c.checktype,
            u.title as nis,
            u.name
        FROM checkinout c
        LEFT JOIN userinfo u ON c.userid = u.userid
        WHERE c.id > ?
        ORDER BY c.id ASC
        LIMIT 100";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $lastId);
$stmt->execute();
$result = $stmt->get_result();

$maxId = $lastId;
$successCount = 0;
$failCount = 0;

while ($row = $result->fetch_assoc()) {
    $currentId = (int) $row['id'];
    
    // Skip jika NIS kosong
    if (empty($row['nis'])) {
        syncLog("Skip ID {$currentId}: NIS kosong untuk user {$row['name']}");
        $maxId = max($maxId, $currentId);
        continue;
    }
    
    // Siapkan data untuk dikirim
    $payload = [
        'nis' => $row['nis'],
        'checktime' => $row['checktime'],
        'checktype' => $row['checktype']
    ];
    
    syncLog("Sending ID {$currentId}: NIS={$row['nis']}, Time={$row['checktime']}, Type={$row['checktype']}");
    
    // Kirim ke API
    $result_api = sendToApi($payload);
    
    if ($result_api['success']) {
        $successCount++;
        $maxId = max($maxId, $currentId);
        syncLog("SUCCESS: ID {$currentId} synced");
    } else {
        $failCount++;
        syncLog("FAILED: ID {$currentId} - HTTP {$result_api['http_code']}");
        // Jika gagal, stop di sini agar bisa retry nanti
        break;
    }
}

// Simpan ID terakhir yang berhasil
if ($maxId > $lastId) {
    saveLastSyncId($maxId);
    syncLog("Updated last sync ID from $lastId to $maxId");
}

syncLog("=== Sync Complete: $successCount success, $failCount failed ===");

$stmt->close();
$conn->close();
?>
